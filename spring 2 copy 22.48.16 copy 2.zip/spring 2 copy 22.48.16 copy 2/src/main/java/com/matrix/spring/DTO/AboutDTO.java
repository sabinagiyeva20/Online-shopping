package com.matrix.spring.DTO;

import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;
@Getter
@Setter
public class AboutDTO {
    private Long id;
    private String imagePath;
    private String questionAboutUs;
    private String answerAboutUs;
}
