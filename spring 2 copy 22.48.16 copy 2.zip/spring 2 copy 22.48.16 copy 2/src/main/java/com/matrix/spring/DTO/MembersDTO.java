package com.matrix.spring.DTO;

import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;
@Getter
@Setter
public class MembersDTO {
    private Long id;
    private String imagePath;
    private String memberName;
    private String memberPosition;
    private String aboutMember;
}
