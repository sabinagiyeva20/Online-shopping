package com.matrix.spring.controller;

import com.matrix.spring.DTO.AboutDTO;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.service.AboutService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("about")
@RequiredArgsConstructor
@Api("About")
public class AboutController {
    private final AboutService aboutService;

    @GetMapping(value = "/id/{id}")
    public AboutDTO getAbout(@PathVariable Long id) {
        return aboutService.getAboutById(id);
    }

    @GetMapping(value = "/answer-about-us/{answerAboutUs}")
    public AboutDTO getAboutByAnswerAboutUs(@PathVariable String answerAboutUs) {
        return aboutService.getAboutByAnswerAboutUs(answerAboutUs);
    }

    @GetMapping(value = "/all-about")
    public  List<AboutDTO> getAllAbout() {
        return aboutService.getAllAbout();
    }

    @PostMapping(value = "/admin/add/about")
    public AboutDTO saveAbout(@RequestBody AboutDTO dto, JwtUser jwtUser) {
        return aboutService.saveAbout(dto, jwtUser);
    }

    @PostMapping(value = "/admin/add/all-about")
    public List<AboutDTO> saveAllAbout(@RequestBody List<AboutDTO> dtoList, JwtUser jwtUser) {
        return aboutService.saveAllAbout(dtoList, jwtUser);
    }

    @DeleteMapping(value = "/admin/question-about-us/{questionAboutUs}")
    public Long deleteAbout(@PathVariable String questionAboutUs, JwtUser jwtUser) {
        return aboutService.deleteByQuestionAboutUs(questionAboutUs, jwtUser);
    }

    @DeleteMapping(value = "/admin/all-about")
    public void deleteAllAbout(JwtUser jwtUser) {
        aboutService.deleteAll(jwtUser);
    }

    @PutMapping(value = "/admin/id-query/{id}/{answerAboutUs}")
    public void updateAboutQuery(@PathVariable Long id, @PathVariable String answerAboutUs, JwtUser jwtUser) {
        aboutService.updateById(id, answerAboutUs, jwtUser);
    }

    @PutMapping(value = "/admin/id/{id}/{answerAboutUs}")
    public AboutDTO updateAbout(@PathVariable Long id, @PathVariable String answerAboutUs, JwtUser jwtUser) {
        return aboutService.updateAnswerAboutUs(id, answerAboutUs, jwtUser);
    }

    @GetMapping(value = "/all/sort")
    public List<AboutDTO> getAboutSort() {
        return aboutService.getAllAboutSort();
    }

    @GetMapping(value = "/all/sort/query")
    public List<AboutDTO> getAboutSortQuery() {
        return aboutService.getAllAboutSortQuery();
    }

    @ApiOperation(value = "Get about with page", response = AboutDTO.class)
    @GetMapping(value = "/all/page")
    public List<AboutDTO> getAboutPage(Pageable page) {
        return aboutService.getAllAboutPage(page);
    }

    @GetMapping(value = "/limit/{limit}")
    public  List<AboutDTO> getLimitedAbout(@PathVariable Integer limit) {
        return aboutService.getLimitedAbout(limit);
    }
}
