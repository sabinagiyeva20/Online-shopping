package com.matrix.spring.controller;

import com.matrix.spring.DTO.CategoryDTO;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.service.CategoryService;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping(value = "category")
@Api("Category")
@RequiredArgsConstructor
public class CategoryController {
    private final CategoryService categoryService;

    @GetMapping("/id/{id}")
    public CategoryDTO getCategory(@PathVariable Long id) {
        return categoryService.getCategoryById(id);
    }

    @GetMapping(value = "/all-about")
    public List<CategoryDTO> getAllCategory() {
        return categoryService.getAllCategories();
    }

    @PostMapping(value = "/admin/add/category")
    public CategoryDTO saveCategory(@RequestBody CategoryDTO dto, JwtUser jwtUser) {
        return categoryService.saveCategory(dto, jwtUser);
    }

    @DeleteMapping(value = "/admin/name/{name}")
    public Long deleteCategory(@PathVariable String name, JwtUser jwtUser) {
        return categoryService.deleteByName(name, jwtUser);
    }

    @PutMapping(value = "/admin/id/{id}/{name}")
    public void updateCategoryQuery(@PathVariable Long id, @PathVariable String name, JwtUser jwtUser) {
        categoryService.updateById(id, name, jwtUser);
    }
}
