package com.matrix.spring.controller;

import com.matrix.spring.DTO.UserDTO;
import com.matrix.spring.entity.User;
import com.matrix.spring.service.UserDetailsServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "registration")
@RequiredArgsConstructor
public class LoginController {
    private final UserDetailsServiceImpl userDetailsService;

    @PostMapping(path = "/login")
    public String login(@RequestBody UserDTO user) {
        return userDetailsService.loadUserByUsernameAndPassword(user.getUsername(), user.getPassword());
    }
}
