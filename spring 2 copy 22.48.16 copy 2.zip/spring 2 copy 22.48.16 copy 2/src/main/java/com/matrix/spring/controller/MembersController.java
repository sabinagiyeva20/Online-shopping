package com.matrix.spring.controller;

import com.matrix.spring.DTO.MembersDTO;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.mapper.MembersMapper;
import com.matrix.spring.service.MembersService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping(value = "members")
@Api("Members")
@RequiredArgsConstructor
@Validated
public class MembersController {
    private final MembersService membersService;
    private final MembersMapper membersMapper;

    @GetMapping(value = "/id/{id}")
    public MembersDTO getMembers(@PathVariable Long id) {
        return membersService.getMembersById(id);
    }

    @GetMapping(value = "/name/{memberName}/about-member/{aboutMember}")
    public MembersDTO getMembersByNameAndAboutMember(@PathVariable String memberName, @PathVariable String aboutMember) {
        return membersService.getMemberByNameAndAboutMember(memberName, aboutMember);
    }

    @GetMapping(value = "/{memberName}/{aboutMember}/{memberPosition}")
    public List<MembersDTO> getMembersByNameAndAboutMemberAndMemberPosition(@PathVariable String memberName,
                                                                            @PathVariable String aboutMember,
                                                                            @PathVariable String memberPosition) {
        var byMemberNameAndAboutMemberAndMemberPosition = membersService.findByMemberNameAndAboutMemberAndMemberPosition(memberName, aboutMember, memberPosition);
        return membersMapper.toDTO(byMemberNameAndAboutMemberAndMemberPosition);
    }

    @GetMapping(value = "/query")
    public List<MembersDTO> getMembersQuery(@RequestParam(required = false) String memberName,
                                            @RequestParam(required = false) String aboutMember,
                                            @RequestParam(required = false) String memberPosition) {
        var byMemberNameAndAboutMemberAndMemberPosition = membersService.findByMemberNameAndAboutMemberAndMemberPosition(memberName, aboutMember, memberPosition);
        return membersMapper.toDTO(byMemberNameAndAboutMemberAndMemberPosition);
    }

    @GetMapping(value = "/all-members")
    public List<MembersDTO> getAllMembers() {
        return membersService.getAllMembers();
    }

    @PostMapping(value = "/admin/add/member")
    public MembersDTO saveMember(@RequestBody MembersDTO dto, JwtUser jwtUser) {
        return membersService.saveMember(dto, jwtUser);
    }

    @PostMapping(value = "/admin/add/all-members")
    public List<MembersDTO> saveAllMembers(@RequestBody List<MembersDTO> dto, JwtUser jwtUser) {
        return membersService.saveAllMembers(dto, jwtUser);
    }

    @DeleteMapping(value = "/admin/member/{memberName}")
    public Long deleteMember(@PathVariable String memberName, JwtUser jwtUser) {
        return membersService.deleteByMembername(memberName, jwtUser);
    }

    @DeleteMapping(value = "/admin/all-members")
    public void deleteAllMembers(JwtUser jwtUser) {
        membersService.deleteAll(jwtUser);
    }

    @PutMapping(value = "/admin/id-query/{id}/{memberName}")
    public void updateMemberQuery(@PathVariable Long id, @PathVariable String memberName, JwtUser jwtUser) {
        membersService.updateById(id, memberName, jwtUser);
    }

    @PutMapping(value = "/admin/id/{id}/{memberName}")
    public MembersDTO updateMember(@PathVariable Long id, @PathVariable String memberName, JwtUser jwtUser) {
        return membersService.updateMemberName(id, memberName, jwtUser);
    }

    @GetMapping(value = "/all/sort")
    public List<MembersDTO> getMembersSort() {
        return membersService.getAllMembersSort();
    }

    @GetMapping(value = "/all/sort/query")
    public List<MembersDTO> getMembersSortQuery() {
        return membersService.getAllMembersSortQuery();
    }

    @ApiOperation(value = "Get members with page", response = MembersDTO.class)
    @GetMapping(value = "/all/page")
    public List<MembersDTO> getAllMembersPage(Pageable page) {
        return membersService.getAllMembersPage(page);
    }

    @GetMapping(value = "/limit/{limit}")
    public List<MembersDTO> getLimitedMembers(@PathVariable Integer limit) {
        return membersService.getLimitedMembers(limit);
    }
}
