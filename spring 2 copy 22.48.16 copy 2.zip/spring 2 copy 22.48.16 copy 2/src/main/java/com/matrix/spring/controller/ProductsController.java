package com.matrix.spring.controller;

import com.matrix.spring.DTO.ProductsDTO;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.service.ProductsService;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping(value = "product")
@Api("Products")
@RequiredArgsConstructor
public class ProductsController {
    private final ProductsService productsService;

    @GetMapping(value = "/id/{id}")
    public ProductsDTO getProducts(@PathVariable Long id){
        return productsService.getProductsById(id);
    }

    @GetMapping(value = "/amount-and-description/{productAmount}/{productDescription}")
    public ProductsDTO getProductsByAmountAndDescription(@PathVariable Double productAmount, @PathVariable String productDescription){
        return productsService.getProductByProductAmountAndProductDescription(productAmount, productDescription);
    }

    @GetMapping(value = "/all-products")
    public List<ProductsDTO> getAllProducts(JwtUser jwtuser){
        return productsService.getAllProducts(jwtuser);
    }

    @PostMapping(value = "/admin/add/product")
    public ProductsDTO saveProduct(@RequestBody ProductsDTO dto,JwtUser jwtUser){
        return productsService.saveProduct(dto,jwtUser);
    }

    @PostMapping(value = "/admin/add/all-products")
    public List<ProductsDTO> saveAllProducts(@RequestBody List<ProductsDTO> dtoList, JwtUser jwtUser){
        return productsService.saveAllProducts(dtoList, jwtUser);
    }

    @DeleteMapping(value = "/admin/amount/{productAmount}")
    public Long deleteProduct(@PathVariable Double productAmount, JwtUser jwtUser){
        return productsService.deleteByProductAmount(productAmount, jwtUser);

    }

    @DeleteMapping(value = "/admin/all-products")
    public void deleteAllProducts(JwtUser jwtUser){
        productsService.deleteAll(jwtUser);
    }

    @PutMapping(value = "/admin/id-query/{id}/{productDescription}")
    public void updateProductQuery(@PathVariable Long id, @PathVariable String productDescription, JwtUser jwtUser){
        productsService.updateById(id, productDescription, jwtUser);
    }

    @PutMapping(value = "/admin/id/{id}/{productDescription}")
    public ProductsDTO updateProduct(@PathVariable Long id, @PathVariable String productDescription, JwtUser jwtUser){
        return productsService.updateProductDescription(id, productDescription, jwtUser);
    }

    @GetMapping(value = "/all/sort")
    public List<ProductsDTO> getProductsSort() {
        return productsService.getAllProductsSort();
    }

    @GetMapping(value = "/all/sort/query")
    public List<ProductsDTO> getProductSortQuery() {
        return productsService.getAllProductsSortQuery();
    }

    @GetMapping(value = "/all/page")
    public List<ProductsDTO> getProductsPage(Pageable page){
        return productsService.getAllProductsPage(page);
    }

    @GetMapping(value = "/limit/{limit}")
    public List<ProductsDTO> getLimitedProduct(@PathVariable int limit){
        return productsService.getLimitedProduct(limit);
    }
}
