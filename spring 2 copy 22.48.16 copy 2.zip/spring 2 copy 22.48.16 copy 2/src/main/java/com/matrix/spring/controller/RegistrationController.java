package com.matrix.spring.controller;

import com.matrix.spring.DTO.RegistrationRequest;
import com.matrix.spring.service.RegisterServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping(path="registration")
public class RegistrationController {
    private final RegisterServiceImpl registerServiceImpl;
    @PostMapping
    public String register(@RequestBody RegistrationRequest request){
        return registerServiceImpl.register(request);
    }

    @GetMapping(path = "/confirm")
    public String confirm(@RequestParam("token") String token) {
        return registerServiceImpl.confirmToken(token);
    }
}