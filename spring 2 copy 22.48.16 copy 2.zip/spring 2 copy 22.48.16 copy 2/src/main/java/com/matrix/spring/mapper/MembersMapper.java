package com.matrix.spring.mapper;

import com.matrix.spring.DTO.MembersDTO;
import com.matrix.spring.entity.MembersEntity;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        injectionStrategy = InjectionStrategy.CONSTRUCTOR
)
public interface MembersMapper {
    MembersDTO toDTO(MembersEntity entity);
    List<MembersDTO> toDTO(List<MembersEntity> entityList);
    MembersEntity fromDTO(MembersDTO dto);
    List<MembersEntity> fromDTO(List<MembersDTO> dtoList);
}
