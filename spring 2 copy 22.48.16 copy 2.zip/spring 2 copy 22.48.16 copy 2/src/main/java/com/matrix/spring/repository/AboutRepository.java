package com.matrix.spring.repository;

import com.matrix.spring.entity.AboutEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Repository
public interface AboutRepository extends JpaRepository<AboutEntity, Long> {
    Optional<AboutEntity> findByAnswerAboutUs(String answerAboutUs);

    @Modifying
    @Transactional
    Long deleteByQuestionAboutUs(String questionAboutUs);

    @Modifying
    @Transactional
    @Query(value = "UPDATE AboutEntity SET answerAboutUs=:answerAboutUs, updatedAt=:dateTime WHERE id=:id")
    void updateAboutById(Long id, String answerAboutUs, LocalDateTime dateTime);

    List<AboutEntity> findAll(Sort sort);

    @Query(value = "Select p from AboutEntity p")
    List<AboutEntity> findAllSort(Sort sort);

    @Query(value = "Select p from AboutEntity p")
    List<AboutEntity> findAllPageable(Pageable page);
}