package com.matrix.spring.repository;

import com.matrix.spring.entity.AboutEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

public class AboutRepositoryImpl {
    @PersistenceContext
    EntityManager entityManager;
    public List<AboutEntity> findLimitedAbout(Integer limit) {
        return entityManager.createQuery("Select p from AboutEntity p order by p.answerAboutUs",
                AboutEntity.class).setMaxResults(limit).getResultList();
    }
}
