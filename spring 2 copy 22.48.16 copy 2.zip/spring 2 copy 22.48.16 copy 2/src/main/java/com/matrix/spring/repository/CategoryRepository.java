package com.matrix.spring.repository;

import com.matrix.spring.entity.CategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import javax.transaction.Transactional;

public interface CategoryRepository extends JpaRepository<CategoryEntity, Long> {
    @Modifying
    @Transactional
    Long deleteByName(String name);

    @Modifying
    @Transactional
    @Query(value = "UPDATE CategoryEntity SET name=:name WHERE id=:id")
    void updateCategoryById(Long id, String name);
}
