package com.matrix.spring.repository;

import com.matrix.spring.entity.MembersEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class MembersDao {
    @PersistenceContext
    EntityManager em;
    public List<MembersEntity> findMembers(String memberName, String aboutMember, String memberPosition) {
        CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
        log.info("memberName {} aboutMember {} memberPosition {}", memberName, aboutMember, memberPosition);
        CriteriaQuery<MembersEntity> criteriaQuery = criteriaBuilder.createQuery(MembersEntity.class);
        Root<MembersEntity> membersEntityRoot = criteriaQuery.from(MembersEntity.class);
        List<Predicate> predicates = new ArrayList<>();
        if(memberName!=null) {
            predicates.add(criteriaBuilder.equal(membersEntityRoot.get("memberName"), memberName));
        }
        if(aboutMember!=null) {
            predicates.add(criteriaBuilder.equal(membersEntityRoot.get("aboutMember"), aboutMember));
        }
        if(memberPosition!=null) {
            predicates.add(criteriaBuilder.equal(membersEntityRoot.get("memberPosition"), memberPosition));
        }
        criteriaQuery.where(predicates.toArray(new Predicate[0]));
        TypedQuery<MembersEntity> query = em.createQuery(criteriaQuery);
        return query.getResultList();
    }
}
