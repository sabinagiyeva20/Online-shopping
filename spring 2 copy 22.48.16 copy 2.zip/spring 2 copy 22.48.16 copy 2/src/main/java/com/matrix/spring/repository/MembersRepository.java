package com.matrix.spring.repository;

import com.matrix.spring.entity.MembersEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface MembersRepository extends JpaRepository<MembersEntity, Long> {
    Optional<MembersEntity> findByMemberNameAndAboutMember(String memberName, String aboutMember);
    List<MembersEntity> findByMemberNameAndAboutMemberAndMemberPosition(String memberName, String aboutMember, String memberPosition);

    @Modifying
    @Transactional
    Long deleteByMemberName(String memberName);

    @Modifying
    @Transactional
    @Query(value = "UPDATE MembersEntity SET memberName=:memberName, updatedAt=:dateTime WHERE id=:id")
    void updateMemberById(Long id, String memberName, LocalDateTime dateTime);

    List<MembersEntity> findAll(Sort sort);

    @Query(value = "Select p from MembersEntity p")
    List<MembersEntity> findAllSort(Sort sort);

    @Query(value = "Select p from MembersEntity p")
    List<MembersEntity> findAllPage(Pageable page);
}
