package com.matrix.spring.repository;

import com.matrix.spring.entity.MembersEntity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

public class MembersRepositoryImpl {
    @PersistenceContext
    EntityManager entityManager;
    public List<MembersEntity> findLimitedMembers(Integer limit) {
        var query =  entityManager.createQuery("Select p from MembersEntity p order by p.memberPosition",
                MembersEntity.class).setMaxResults(limit);
        return query.getResultList();
    }
}