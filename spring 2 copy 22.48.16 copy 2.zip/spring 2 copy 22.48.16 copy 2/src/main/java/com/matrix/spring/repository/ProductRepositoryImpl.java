package com.matrix.spring.repository;

import com.matrix.spring.entity.ProductsEntity;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class ProductRepositoryImpl {
    @PersistenceContext
    EntityManager entityManager;
    public List<ProductsEntity> findLimitedProduct(int limit){
        return entityManager.createQuery("Select p from ProductsEntity p order by p.productDescription",
                ProductsEntity.class).setMaxResults(limit).getResultList();
    }
}
