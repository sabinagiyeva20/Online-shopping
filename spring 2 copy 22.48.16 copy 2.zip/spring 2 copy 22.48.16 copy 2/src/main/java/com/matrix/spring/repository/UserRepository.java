package com.matrix.spring.repository;

import com.matrix.spring.entity.User;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    @EntityGraph(attributePaths = {"authorities"})
    Optional<User> findFirstByUsername(String username);

    @Transactional
    @Modifying
    @Query(value = "UPDATE User a " + "SET a.enabled = TRUE WHERE a.username = ?1")
    int enableAppUser(String username);
}
