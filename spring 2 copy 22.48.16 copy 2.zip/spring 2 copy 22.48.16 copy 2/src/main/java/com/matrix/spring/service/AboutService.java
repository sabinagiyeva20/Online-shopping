package com.matrix.spring.service;

import com.matrix.spring.DTO.AboutDTO;
import com.matrix.spring.jwt.JwtUser;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public interface AboutService {
    AboutDTO getAboutById(Long id);
    AboutDTO getAboutByAnswerAboutUs(String answerAboutUs);
    List<AboutDTO> getAllAbout();
    AboutDTO saveAbout(AboutDTO dto, JwtUser jwtUser);
    List<AboutDTO> saveAllAbout(List<AboutDTO> dtoList, JwtUser jwtUser);
    Long deleteByQuestionAboutUs(String questionAboutUs, JwtUser jwtUser);
    void deleteAll(JwtUser jwtUser);
    void updateById(Long id, String answerAboutUs, JwtUser jwtUser);
    AboutDTO updateAnswerAboutUs(Long id, String answerAboutUs, JwtUser jwtUser);
    List<AboutDTO> getAllAboutSort();
    List<AboutDTO> getAllAboutSortQuery();
    List<AboutDTO> getAllAboutPage(Pageable page);
    List<AboutDTO> getLimitedAbout(Integer limit);
}
