package com.matrix.spring.service;

import com.matrix.spring.DTO.AboutDTO;
import com.matrix.spring.entity.AboutEntity;
import com.matrix.spring.exception.BadRequestException;
import com.matrix.spring.exception.NotFoundException;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.mapper.AboutMapper;
import com.matrix.spring.repository.AboutRepository;
import com.matrix.spring.repository.AboutRepositoryImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.JpaSort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AboutServiceImpl implements AboutService{
    private final AboutRepository aboutRepository;
    private final AboutMapper aboutMapper;
    private final AboutRepositoryImpl aboutRepositoryImpl;

    @Override
    public AboutDTO getAboutById(Long id) {
        AboutEntity entity = getEntity(id);
        return aboutMapper.toDTO(entity);
    }

    @Override
    public AboutDTO getAboutByAnswerAboutUs(String answerAboutUs) {
        var entity = aboutRepository.findByAnswerAboutUs(answerAboutUs)
                .orElseGet(()->new AboutEntity());
        return aboutMapper.toDTO(entity);
    }

    @Override
    public List<AboutDTO> getAllAbout() {
        List<AboutEntity> all = aboutRepository.findAll();
        return aboutMapper.toDTO(all);
    }

    @Override
    public AboutDTO saveAbout(AboutDTO dto, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        AboutEntity entity = aboutMapper.fromDTO(dto);
        AboutEntity save = aboutRepository.save(entity);
        return aboutMapper.toDTO(save);
    }

    @Override
    public List<AboutDTO> saveAllAbout(List<AboutDTO> dtoList, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        List<AboutEntity> entityList = aboutMapper.fromDTO(dtoList);
        List<AboutEntity> aboutEntities = aboutRepository.saveAll(entityList);
        return aboutMapper.toDTO(aboutEntities);
    }

    @Override
    public Long deleteByQuestionAboutUs(String questionAboutUs, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        return aboutRepository.deleteByQuestionAboutUs(questionAboutUs);
    }

    @Override
    public void deleteAll(JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        aboutRepository.deleteAll();
    }

    @Override
    public void updateById(Long id, String answerAboutUs, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        AboutDTO aboutById = getAboutById(id);
        if(aboutById == null) {
            throw new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id));
        } else {
            aboutRepository.updateAboutById(id, answerAboutUs, LocalDateTime.now());
        }
    }

    @Override
    public AboutDTO updateAnswerAboutUs(Long id, String answerAboutUs, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        AboutEntity entity = getEntity(id);
        System.err.println(entity.getAnswerAboutUs());
        entity.setAnswerAboutUs(answerAboutUs);
        entity.setUpdatedAt(LocalDateTime.now());
        AboutEntity save = aboutRepository.save(entity);
        System.err.println(entity.getAnswerAboutUs());
        return aboutMapper.toDTO(save);
    }

    private AboutEntity getEntity(Long id) {
        return aboutRepository.findById(id).orElseThrow(()->
                new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id)));
    }

    @Override
    public List<AboutDTO> getAllAboutSort() {
        List<AboutEntity> questionAboutUs = aboutRepository.findAll(Sort.by(Sort.Direction.DESC, "questionAboutUs"));
        return aboutMapper.toDTO(questionAboutUs);
    }

    @Override
    public List<AboutDTO> getAllAboutSortQuery() {
        List<AboutEntity> allSort = aboutRepository.findAllSort(JpaSort.unsafe(Sort.Direction.DESC, "Length(questionAboutUs)"));
        return aboutMapper.toDTO(allSort);
    }

    @Override
    public List<AboutDTO> getAllAboutPage(Pageable page) {
        List<AboutEntity> allPageable = aboutRepository.findAllPageable(page);
        return aboutMapper.toDTO(allPageable);
    }

    @Override
    public List<AboutDTO> getLimitedAbout(Integer limit) {
        var aboutLimited = aboutRepositoryImpl.findLimitedAbout(limit);
        return aboutMapper.toDTO(aboutLimited);
    }
}
