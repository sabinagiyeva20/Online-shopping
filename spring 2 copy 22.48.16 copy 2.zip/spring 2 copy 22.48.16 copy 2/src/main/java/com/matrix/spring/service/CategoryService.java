package com.matrix.spring.service;

import com.matrix.spring.DTO.CategoryDTO;
import com.matrix.spring.jwt.JwtUser;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CategoryService {
    CategoryDTO getCategoryById(Long id);
    List<CategoryDTO> getAllCategories();
    CategoryDTO saveCategory(CategoryDTO dto, JwtUser jwtUser);
    Long deleteByName(String name, JwtUser jwtUser);
    void updateById(Long id, String name, JwtUser jwtUser);
}
