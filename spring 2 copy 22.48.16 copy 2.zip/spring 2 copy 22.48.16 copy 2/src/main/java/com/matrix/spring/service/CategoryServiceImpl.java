package com.matrix.spring.service;

import com.matrix.spring.DTO.CategoryDTO;
import com.matrix.spring.entity.CategoryEntity;
import com.matrix.spring.exception.BadRequestException;
import com.matrix.spring.exception.NotFoundException;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.mapper.CategoryMapper;
import com.matrix.spring.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService{
    private final CategoryRepository categoryRepository;
    private final CategoryMapper categoryMapper;

    @Override
    public CategoryDTO getCategoryById(Long id) {
        CategoryEntity entity = getEntity(id);
        return categoryMapper.toDTO(entity);
    }

    @Override
    public List<CategoryDTO> getAllCategories() {
        List<CategoryEntity> all = categoryRepository.findAll();
        return categoryMapper.toDTO(all);
    }

    @Override
    public CategoryDTO saveCategory(CategoryDTO dto, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        CategoryEntity entity = categoryMapper.fromDTO(dto);
        CategoryEntity save = categoryRepository.save(entity);
        return categoryMapper.toDTO(save);
    }

    @Override
    public Long deleteByName(String name, JwtUser jwtUser){
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        return categoryRepository.deleteByName(name);
    }

    @Override
    public void updateById(Long id, String name, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        CategoryDTO categoryById = getCategoryById(id);
        if(categoryById == null) {
            throw new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id));
        } else {
            categoryRepository.updateCategoryById(id, name);
        }
    }

    private CategoryEntity getEntity(Long id) {
        return categoryRepository.findById(id).orElseThrow(()->
                new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id)));
    }
}
