package com.matrix.spring.service;

import com.matrix.spring.entity.User;
import com.matrix.spring.entity.UserGrantedAuthority;
import com.matrix.spring.property.JwtProperty;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.Map;
import java.util.stream.Collectors;
import io.jsonwebtoken.Claims;

@Service
@Slf4j
@RequiredArgsConstructor
public class JwtServiceImpl implements JwtService {
//    private Key key;
    private final JwtProperty jwtProperty;

//    @PostConstruct
//    private void init(){
//        String signKey = jwtProperty.getSecretKey();
//        byte[] keyIntByte = Decoders.BASE64URL.decode(signKey);
//        key = Keys.hmacShaKeyFor(keyIntByte);
//    }

    @Override
    public String createJwt(User user) {
        JwtBuilder jwtBuilder = Jwts.builder()
                .setId(String.valueOf(user.getId()))
                .setSubject(user.getUsername())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + jwtProperty.getExpiration() * 5000L))  // add 5 minutes
                .addClaims(Map.of("roles", user.getAuthorities()
                        .stream()
                        .map(UserGrantedAuthority::getAuthority).collect(Collectors.toList())))
                .setHeader(Map.of("type", "JWT"))
//                .signWith(key, SignatureAlgorithm.HS256);
                .signWith(SignatureAlgorithm.HS512, jwtProperty.getSecretKey().getBytes(StandardCharsets.UTF_8));
        return jwtBuilder.compact();
    }

    @Override
    public Claims verifyJwt(String token) {
//        var claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody();
        var claims = Jwts.parser()
                .setSigningKey(jwtProperty.getSecretKey().getBytes(StandardCharsets.UTF_8))
                .parseClaimsJws(token)
                .getBody();
        if(claims.getExpiration().before(new Date())) {
            throw new RuntimeException("Token expired");
        }
       return  claims;
    }
}
