package com.matrix.spring.service;

import com.matrix.spring.DTO.MembersDTO;
import com.matrix.spring.entity.MembersEntity;
import com.matrix.spring.jwt.JwtUser;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public interface MembersService {
    MembersDTO getMembersById(Long id);

    MembersDTO getMemberByNameAndAboutMember(String memberName, String aboutMember);

    List<MembersEntity> findByMemberNameAndAboutMemberAndMemberPosition(String memberName, String aboutMember, String memberPosition);

    List<MembersDTO> getAllMembers();

    MembersDTO saveMember(MembersDTO dto, JwtUser jwtUser);

    List<MembersDTO> saveAllMembers(List<MembersDTO> dtoList, JwtUser jwtUser);

    Long deleteByMembername(String memberName, JwtUser jwtUser);

    void deleteAll(JwtUser jwtUser);

    void updateById(Long id, String memberName, JwtUser jwtUser);

    MembersDTO updateMemberName(Long id, String memberName, JwtUser jwtUser);

    List<MembersDTO> getAllMembersSort();

    List<MembersDTO> getAllMembersSortQuery();
    List<MembersDTO> getAllMembersPage(Pageable page);
    List<MembersDTO> getLimitedMembers(Integer limit);
}