package com.matrix.spring.service;

import com.matrix.spring.DTO.MembersDTO;
import com.matrix.spring.entity.MembersEntity;
import com.matrix.spring.exception.BadRequestException;
import com.matrix.spring.exception.NotFoundException;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.mapper.MembersMapper;
import com.matrix.spring.repository.MembersDao;
import com.matrix.spring.repository.MembersRepository;
import com.matrix.spring.repository.MembersRepositoryImpl;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.JpaSort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class MembersServiceImpl implements MembersService{
    private final MembersRepository membersRepository;
    private final MembersMapper membersMapper;
    private final MembersRepositoryImpl membersRepositoryImpl;
    private final MembersDao membersDao;

    @Override
    public MembersDTO getMembersById(Long id) {
        MembersEntity membersEntity = getEntity(id);
        return membersMapper.toDTO(membersEntity);
    }

    @Override
    public MembersDTO getMemberByNameAndAboutMember(String memberName, String aboutMember) {
        var membersEntity = membersRepository.findByMemberNameAndAboutMember(memberName, aboutMember)
                .orElseGet(()-> new MembersEntity());
        return membersMapper.toDTO(membersEntity);
    }

    @Override
    public List<MembersEntity> findByMemberNameAndAboutMemberAndMemberPosition(String memberName, String aboutMember, String memberPosition) {
        var membersEntity = membersDao.findMembers(memberName, aboutMember, memberPosition);
        return membersEntity;
    }

    @Override
    public List<MembersDTO> getAllMembers() {
        List<MembersEntity> all = membersRepository.findAll();
        return membersMapper.toDTO(all);
    }

    @Override
    public MembersDTO saveMember(MembersDTO dto, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        MembersEntity entity = membersMapper.fromDTO(dto);
        MembersEntity save = membersRepository.save(entity);
        return membersMapper.toDTO(save);
    }

    @Override
    public List<MembersDTO> saveAllMembers(List<MembersDTO> dtoList, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        List<MembersEntity> entityList = membersMapper.fromDTO(dtoList);
        List<MembersEntity> membersEntities = membersRepository.saveAll(entityList);
        return membersMapper.toDTO(membersEntities);
    }

    @Override
    public Long deleteByMembername(String memberName, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        Long deletedRows = membersRepository.deleteByMemberName(memberName);
        return deletedRows;
    }

    @Override
    public void deleteAll(JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        membersRepository.deleteAll();
    }

    @Override
    public void updateById(Long id, String memberName, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        MembersDTO membersById = getMembersById(id);
        if(membersById == null) {
            throw new NotFoundException(HttpStatus.NOT_FOUND, 1, String.format("ID %s uzre melumat tapilmadi", id));
        } else {
            membersRepository.updateMemberById(id, memberName, LocalDateTime.now());
        }
    }

    @Override
    public MembersDTO updateMemberName(Long id, String memberName, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        MembersEntity entity = getEntity(id);
        System.err.println(entity.getMemberName());
        entity.setMemberName(memberName);
        entity.setUpdatedAt(LocalDateTime.now());
        MembersEntity savedEntity = membersRepository.save(entity);
        System.err.println(savedEntity.getMemberName());
        return membersMapper.toDTO(savedEntity);
    }

    private MembersEntity getEntity(Long id) {
        return membersRepository.findById(id).orElseThrow(()->
                new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id)));
    }

    @Override
    public List<MembersDTO> getAllMembersSort() {
        List<MembersEntity> id = membersRepository.findAll(Sort.by(Sort.Direction.DESC, "id"));
        return membersMapper.toDTO(id);
    }

    @Override
    public List<MembersDTO> getAllMembersSortQuery() {
        List<MembersEntity> allSort = membersRepository.findAllSort(JpaSort.unsafe(Sort.Direction.DESC, "Length(memberPosition)"));
        return membersMapper.toDTO(allSort);
    }

    @Override
    public List<MembersDTO> getAllMembersPage(Pageable page) {
        List<MembersEntity> allPage = membersRepository.findAllPage(page);
        return membersMapper.toDTO(allPage);
    }

    @Override
    public List<MembersDTO> getLimitedMembers(Integer limit) {
        var limitedMembers = membersRepositoryImpl.findLimitedMembers(limit);
        return membersMapper.toDTO(limitedMembers);
    }
}
