package com.matrix.spring.service;

import com.matrix.spring.DTO.ProductsDTO;
import com.matrix.spring.jwt.JwtUser;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public interface ProductsService {
    ProductsDTO getProductsById(Long id);

    ProductsDTO getProductByProductAmountAndProductDescription(Double productAmount, String productDescription);

    List<ProductsDTO> getAllProducts(JwtUser jwtuser);

    ProductsDTO saveProduct(ProductsDTO dto, JwtUser jwtUser);

    List<ProductsDTO> saveAllProducts(List<ProductsDTO> dtoList, JwtUser jwtUser);

    Long deleteByProductAmount(Double productAmount, JwtUser jwtUser);

    void deleteAll(JwtUser jwtUser);

    void updateById(Long id, String productDescription, JwtUser jwtUser);

    ProductsDTO updateProductDescription(Long id, String productDescription, JwtUser jwtUser);

    List<ProductsDTO> getAllProductsSort();

    List<ProductsDTO> getAllProductsSortQuery();

    List<ProductsDTO> getAllProductsPage(Pageable page);

    List<ProductsDTO> getLimitedProduct(int limit);
}
