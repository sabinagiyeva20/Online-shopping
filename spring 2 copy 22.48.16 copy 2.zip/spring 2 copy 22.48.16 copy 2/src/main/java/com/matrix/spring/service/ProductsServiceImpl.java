package com.matrix.spring.service;

import com.matrix.spring.DTO.ProductsDTO;
import com.matrix.spring.entity.ProductsEntity;
import com.matrix.spring.exception.BadRequestException;
import com.matrix.spring.exception.NotFoundException;
import com.matrix.spring.jwt.JwtUser;
import com.matrix.spring.mapper.ProductsMapper;
import com.matrix.spring.repository.ProductRepositoryImpl;
import com.matrix.spring.repository.ProductsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.JpaSort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ProductsServiceImpl implements ProductsService{
    private final ProductsRepository productsRepository;
    private final ProductsMapper productsMapper;
    private final ProductRepositoryImpl productRepositoryImpl;

    @Override
    public ProductsDTO getProductsById(Long id) {
        ProductsEntity productsEntity = getEntity(id);
        return productsMapper.toDTO(productsEntity);
    }

    @Override
    public ProductsDTO getProductByProductAmountAndProductDescription(Double productAmount, String productDescription) {
        var productsEntity = productsRepository.findByProductAmountAndProductDescription(productAmount, productDescription)
                .orElseGet(()-> new ProductsEntity());
        return productsMapper.toDTO(productsEntity);
    }

    @Override
    public List<ProductsDTO> getAllProducts(JwtUser jwtUser) {
        List<ProductsEntity> all = productsRepository.findAll();
        return productsMapper.toDTO(all);
    }

    @Override
    public ProductsDTO saveProduct(ProductsDTO dto,JwtUser jwtUser) {
        log.info("jwtuser= {}",jwtUser);
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());

        if (userRole.isEmpty()){
            throw new BadRequestException(HttpStatus.BAD_REQUEST,400,"Only admin");
        }
        log.info("dto   {}",dto);
        ProductsEntity entity = productsMapper.fromDTO(dto);
        ProductsEntity save = productsRepository.save(entity);
        return productsMapper.toDTO(save);
    }

    @Override
    public List<ProductsDTO> saveAllProducts(List<ProductsDTO> dtoList, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        List<ProductsEntity> entityList = productsMapper.fromDTO(dtoList);
        List<ProductsEntity> productsEntities = productsRepository.saveAll(entityList);
        return productsMapper.toDTO(productsEntities);
    }

    @Override
    public Long deleteByProductAmount(Double productAmount, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        return productsRepository.deleteByProductAmount(productAmount);
    }

    @Override
    public void deleteAll(JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        productsRepository.deleteAll();
    }

    @Override
    public void updateById(Long id, String productDescription, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        ProductsDTO productsById = getProductsById(id);
        if (productsById==null){
            throw new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id));
        } else {
            productsRepository.updateProductById(id, productDescription, LocalDateTime.now());
        }
    }

    @Override
    public ProductsDTO updateProductDescription(Long id, String productDescription, JwtUser jwtUser) {
        var userRole = jwtUser.getRoles().stream()
                .filter(u->u.getAuthority().equals("ROLE_ADMIN")).collect(Collectors.toList());
        if (userRole.isEmpty()) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, 400, "Only admin");
        }
        ProductsEntity entity = getEntity(id);
        System.err.println(entity.getProductDescription());
        entity.setProductDescription(productDescription);
        entity.setUpdatedAt(LocalDateTime.now());
        ProductsEntity savedEntity = productsRepository.save(entity);
        System.err.println(savedEntity.getProductDescription());
        return productsMapper.toDTO(savedEntity);
    }

    private ProductsEntity getEntity(Long id){
        return productsRepository.findById(id).orElseThrow(()->
                new NotFoundException(HttpStatus.NOT_FOUND, 2, String.format("ID %s uzre melumat tapilmadi", id)));
    }

    @Override
    public List<ProductsDTO> getAllProductsSort() {
        List<ProductsEntity> productName = productsRepository.findAll(Sort.by(Sort.Direction.DESC, "productName"));
        return productsMapper.toDTO(productName);
    }

    @Override
    public List<ProductsDTO> getAllProductsSortQuery() {
        List<ProductsEntity> allSort = productsRepository.findAllSort(JpaSort.unsafe(Sort.Direction.DESC, "LENGTH(productDescription)"));
        return productsMapper.toDTO(allSort);
    }

    @Override
    public List<ProductsDTO> getAllProductsPage(Pageable page) {
        List<ProductsEntity> allPageable = productsRepository.findAllPageable(page);
        return productsMapper.toDTO(allPageable);
    }

    @Override
    public List<ProductsDTO> getLimitedProduct(int limit) {
        var productLimited = productRepositoryImpl.findLimitedProduct(limit);
        return productsMapper.toDTO(productLimited);
    }

}
