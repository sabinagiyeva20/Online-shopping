package com.matrix.spring.service;

import com.matrix.spring.DTO.RegistrationRequest;

public interface RegisterService {
    String register(RegistrationRequest registrationRequest);
}
