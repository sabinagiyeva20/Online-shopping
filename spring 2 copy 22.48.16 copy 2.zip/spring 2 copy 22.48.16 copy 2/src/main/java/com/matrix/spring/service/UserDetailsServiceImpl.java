package com.matrix.spring.service;

import com.matrix.spring.entity.ConfirmationTokenEntity;
import com.matrix.spring.entity.User;
import com.matrix.spring.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserDetailsServiceImpl implements UserDetailsService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    private final ConfirmationTokenService confirmationTokenService;
    private final JwtService jwtService;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findFirstByUsername(username).orElseThrow(()->new UsernameNotFoundException("Email not found"));
    }

    public String  loadUserByUsernameAndPassword(String email,String password) throws UsernameNotFoundException {
        var user = userRepository.findFirstByUsername(email).orElseThrow(()->new UsernameNotFoundException("Email not found"));
        if(bCryptPasswordEncoder.matches(password, user.getPassword())){
            return jwtService.createJwt(user);
        }
        else {
            throw new UsernameNotFoundException("User not found");
        }
    }

    public String signUpUser(User user){
        boolean userExists = userRepository.findFirstByUsername(user.getUsername()).isPresent();
        if(userExists){
            throw new IllegalStateException("email already taken");
        }
        String encodedPassword = bCryptPasswordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        userRepository.save(user);
        String token = UUID.randomUUID().toString();
        ConfirmationTokenEntity confirmationTokenEntity = new ConfirmationTokenEntity(
                token,
                LocalDateTime.now(),
                LocalDateTime.now().plusMinutes(15),
                user
        );
        confirmationTokenService.saveConfirmationToken(confirmationTokenEntity);
        return token;
    }
    public int enableAppUser(String email){
        return userRepository.enableAppUser(email);
    }
}
