create table public.about(
    id int4 GENERATED ALWAYS AS IDENTITY,
    image_path varchar(300),
    question_about_us varchar(50),
    answer_about_us varchar(300),
    created_at timestamp,
    updated_at timestamp,
    CONSTRAINT about_akey PRIMARY KEY (id)
);

insert into public.about(image_path, question_about_us, answer_about_us) values ('nese.jpg', 'nese2', 'bashqanese2');

create table public.underabout(
    id int4 GENERATED ALWAYS AS IDENTITY,
    unique_answer varchar(50),
    created_at timestamp,
    updated_at timestamp,
    CONSTRAINT underabout_ukey PRIMARY KEY (id)
);

insert into public.underabout(unique_answer) values ('nese');
